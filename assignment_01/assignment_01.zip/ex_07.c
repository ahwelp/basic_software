/*
Questão 7 (1,5 pontos): Analise uma lista de palavras de tamanhos 
variados, e identifique a primeira e a última palavra em relação à ordem 
alfabética. Por exemplo, em uma 
lista {"nh", "wa", "ix", "es", "ck"}, a primeira seria "ck", e a 
última "wa".*/
#include <stdio.h>

int main(){

}
